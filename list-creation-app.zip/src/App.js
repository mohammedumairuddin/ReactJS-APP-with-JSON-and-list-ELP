import React from 'react';
import Header from './components/Header';
import ListDisplay from './components/ListDisplay';
import ListForm from './components/ListForm';

function App() {
  return (
    <div>
      <Header />
      <ListForm />
      <ListDisplay />
    </div>
  );
}

export default App;
