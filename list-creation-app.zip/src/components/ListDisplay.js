import React, { useState, useEffect } from 'react';

function ListDisplay() {
  const [lists, setLists] = useState([]);

  useEffect(() => {
    fetch('https://apis.ccbp.in/list-creation/lists')
      .then((response) => response.json())
      .then((data) => setLists(data))
      .catch((error) => console.error('Error fetching lists:', error));
  }, []);

  return (
    <div>
      <h2>Lists</h2>
      <ul>
        {lists.map((list) => (
          <li key={list.id}>{list.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default ListDisplay;
