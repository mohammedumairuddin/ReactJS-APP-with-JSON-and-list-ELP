import React, { useState } from 'react';

function ListForm() {
  const [listName, setListName] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('https://apis.ccbp.in/list-creation/lists', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: listName }),
    })
      .then((response) => response.json())
      .then(() => setListName(''))
      .catch((error) => console.error('Error creating list:', error));
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={listName}
        onChange={(e) => setListName(e.target.value)}
        placeholder="Enter list name"
      />
      <button type="submit">Create List</button>
    </form>
  );
}

export default ListForm;
